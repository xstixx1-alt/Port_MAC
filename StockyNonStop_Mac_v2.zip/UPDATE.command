#!/bin/bash
# ============================================================
#  Stocky non Stop — Auto-Updater
#  Двойной клик = проверка обновлений + скачивание + запуск
# ============================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Ищем config.sh рядом или в INSTALL_DIR
if [[ -f "${SCRIPT_DIR}/config.sh" ]]; then
    source "${SCRIPT_DIR}/config.sh"
elif [[ -f "${INSTALL_DIR}/config.sh" ]]; then
    source "${INSTALL_DIR}/config.sh"
else
    echo "config.sh не найден!"
    exit 1
fi

# Если INSTALL_DIR не существует — это первый запуск, нужен INSTALL.command
if [[ ! -d "$INSTALL_DIR" ]]; then
    echo "Приложение не установлено. Запустите INSTALL.command сначала."
    read -n 1 -s -r -p "Нажмите любую клавишу..."
    exit 1
fi

cd "$INSTALL_DIR"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

clear
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║${NC}  ${BOLD}Stocky non Stop${NC} — Updater                ${CYAN}║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════╝${NC}"
echo ""

# --- Проверка конфига ---
if [[ "$GITHUB_REPO" == "CHANGEME/CHANGEME" ]]; then
    echo -e "${RED}[✗]${NC} config.sh не настроен!"
    echo -e "    Откройте config.sh и укажите GITHUB_REPO"
    echo ""
    read -n 1 -s -r -p "Нажмите любую клавишу для запуска..."
    cd "$INSTALL_DIR"
    source .venv/bin/activate
    python3 main.py
    exit 0
fi

# --- Локальная версия ---
LOCAL_VERSION="0.0.0"
if [[ -f "$VERSION_FILE" ]]; then
    LOCAL_VERSION=$(cat "$VERSION_FILE" | tr -d '[:space:]')
fi
echo -e "  Текущая версия:  ${BOLD}${LOCAL_VERSION}${NC}"

# --- Проверяем GitHub ---
echo -e "${CYAN}Проверяю обновления...${NC}"

RELEASE_JSON=$(curl -sL "$GITHUB_API" 2>/dev/null || echo "")

if [[ -z "$RELEASE_JSON" ]] || echo "$RELEASE_JSON" | grep -q '"message"'; then
    echo -e "${YELLOW}[!]${NC} Не удалось проверить обновления. Нет интернета?"
    echo ""
    read -n 1 -s -r -p "Нажмите любую клавишу для запуска..."
    cd "$INSTALL_DIR"
    source .venv/bin/activate
    python3 main.py
    exit 0
fi

REMOTE_VERSION=$(echo "$RELEASE_JSON" | python3 -c "
import sys, json
data = json.load(sys.stdin)
tag = data.get('tag_name', '')
print(tag.lstrip('v'))
" 2>/dev/null || echo "")

if [[ -z "$REMOTE_VERSION" ]]; then
    echo -e "${YELLOW}[!]${NC} Не удалось определить версию релиза"
    read -n 1 -s -r -p "Нажмите любую клавишу для запуска..."
    cd "$INSTALL_DIR"
    source .venv/bin/activate
    python3 main.py
    exit 0
fi

echo -e "  Последняя версия: ${BOLD}${REMOTE_VERSION}${NC}"
echo ""

# --- Сравнение версий ---
version_gt() {
    # Возвращает 0 если $1 > $2
    python3 -c "
import sys
v1 = list(map(int, '$1'.split('.')))
v2 = list(map(int, '$2'.split('.')))
sys.exit(0 if v1 > v2 else 1)
" 2>/dev/null
}

if ! version_gt "$REMOTE_VERSION" "$LOCAL_VERSION"; then
    echo -e "${GREEN}[✓]${NC} У вас последняя версия! Обновление не требуется."
    echo ""
    read -n 1 -s -r -p "Нажмите любую клавишу для запуска..."
    cd "$INSTALL_DIR"
    source .venv/bin/activate
    python3 main.py
    exit 0
fi

# --- Есть обновление ---
echo -e "${CYAN}╔══════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║${NC}  ${GREEN}${BOLD}Доступно обновление!${NC}                     ${CYAN}║${NC}"
echo -e "${CYAN}║${NC}  ${LOCAL_VERSION} → ${BOLD}${REMOTE_VERSION}${NC}                    ${CYAN}║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════╝${NC}"
echo ""

# Показываем описание релиза если есть
RELEASE_NOTES=$(echo "$RELEASE_JSON" | python3 -c "
import sys, json
data = json.load(sys.stdin)
body = data.get('body', '').strip()
if body:
    # Берём первые 5 строк
    lines = body.split('\n')[:5]
    for l in lines:
        print('  ' + l)
" 2>/dev/null || echo "")

if [[ -n "$RELEASE_NOTES" ]]; then
    echo -e "${CYAN}Что нового:${NC}"
    echo "$RELEASE_NOTES"
    echo ""
fi

# Автообновление (без вопроса — Valerij тугодум)
echo -e "${CYAN}[1/4]${NC} Скачиваю обновление..."

DOWNLOAD_URL=$(echo "$RELEASE_JSON" | python3 -c "
import sys, json
data = json.load(sys.stdin)
for asset in data.get('assets', []):
    name = asset.get('name', '')
    if name.endswith('.zip') and 'Mac' in name:
        print(asset['browser_download_url'])
        break
else:
    print(data.get('zipball_url', ''))
" 2>/dev/null || echo "")

if [[ -z "$DOWNLOAD_URL" ]]; then
    echo -e "${RED}[✗]${NC} Не найден zip в релизе"
    read -n 1 -s -r -p "Нажмите любую клавишу для запуска..."
    cd "$INSTALL_DIR"
    source .venv/bin/activate
    python3 main.py
    exit 0
fi

TMP_ZIP="/tmp/${APP_NAME}_${REMOTE_VERSION}.zip"
curl -L -o "$TMP_ZIP" "$DOWNLOAD_URL" --progress-bar

echo -e "${CYAN}[2/4]${NC} Распаковываю..."

TMP_EXTRACT="/tmp/${APP_NAME}_update"
rm -rf "$TMP_EXTRACT"
mkdir -p "$TMP_EXTRACT"
unzip -qo "$TMP_ZIP" -d "$TMP_EXTRACT"

# Находим папку внутри zip
INNER=$(find "$TMP_EXTRACT" -maxdepth 1 -type d | tail -1)
if [[ "$INNER" == "$TMP_EXTRACT" ]]; then
    INNER="$TMP_EXTRACT"
fi

# Распаковываем НЕ трогая пользовательские файлы
echo -e "${CYAN}[3/4]${NC} Обновляю файлы (настройки сохранены)..."

rsync -a \
    --exclude='config.json' \
    --exclude='settings.json' \
    --exclude='models/' \
    --exclude='downloads/' \
    --exclude='voicer_debug.log' \
    --exclude='.venv/' \
    --exclude='__pycache__/' \
    --exclude='build/' \
    --exclude='dist/' \
    --exclude='logs/' \
    "${INNER}/" "${INSTALL_DIR}/"

rm -rf "$TMP_ZIP" "$TMP_EXTRACT"

# Записываем новую версию
echo "$REMOTE_VERSION" > "${INSTALL_DIR}/version.txt"

# --- Обновляем pip если requirements изменился ---
echo -e "${CYAN}[4/4]${NC} Проверяю Python-зависимости..."
if [[ -d "${INSTALL_DIR}/.venv" ]]; then
    source "${INSTALL_DIR}/.venv/bin/activate"
    if [[ -f "${INSTALL_DIR}/requirements_mac.txt" ]]; then
        pip install -q -r "${INSTALL_DIR}/requirements_mac.txt" 2>/dev/null
    fi
fi

echo ""
echo -e "${GREEN}${BOLD}Обновлено до версии ${REMOTE_VERSION}!${NC}"
echo ""
read -n 1 -s -r -p "Нажмите любую клавишу для запуска..."

# ============================================================
#  Запуск
# ============================================================
cd "$INSTALL_DIR"
source .venv/bin/activate
python3 main.py
