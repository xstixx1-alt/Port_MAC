#!/bin/bash
# ============================================================
#  Stocky non Stop — macOS Installer v2
#  Двойной клик = установка + запуск
#  Скачивает последнюю версию с GitHub Releases
# ============================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

clear
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║${NC}  ${BOLD}Stocky non Stop${NC} — macOS Installer       ${CYAN}║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════╝${NC}"
echo ""

# --- Проверка конфига ---
if [[ "$GITHUB_REPO" == "CHANGEME/CHANGEME" ]]; then
    echo -e "${YELLOW}[!]${NC} config.sh не настроен — используем локальную установку"
    USE_LOCAL=true
else
    USE_LOCAL=false
fi

# ============================================================
#  РЕЖИМ 1: Скачивание с GitHub
# ============================================================
if [[ "$USE_LOCAL" == "false" ]]; then
    echo -e "${CYAN}[1/6]${NC} Проверяю последнюю версию на GitHub..."

    RELEASE_JSON=$(curl -sL "$GITHUB_API" 2>/dev/null || echo "")
    if [[ -z "$RELEASE_JSON" ]] || echo "$RELEASE_JSON" | grep -q '"message"'; then
        echo -e "${RED}[✗]${NC} Не удалось получить релиз. Проверьте GITHUB_REPO в config.sh"
        echo -e "    Используем локальную установку..."
        USE_LOCAL=true
    else
        REMOTE_VERSION=$(echo "$RELEASE_JSON" | python3 -c "
import sys, json
data = json.load(sys.stdin)
tag = data.get('tag_name', '')
print(tag.lstrip('v'))
" 2>/dev/null || echo "")

        if [[ -z "$REMOTE_VERSION" ]]; then
            echo -e "${RED}[✗]${NC} Не удалось определить версию релиза"
            USE_LOCAL=true
        else
            echo -e "${GREEN}[✓]${NC} Последняя версия: ${BOLD}${REMOTE_VERSION}${NC}"

            # Ищем zip asset в релизе
            DOWNLOAD_URL=$(echo "$RELEASE_JSON" | python3 -c "
import sys, json
data = json.load(sys.stdin)
for asset in data.get('assets', []):
    name = asset.get('name', '')
    if name.endswith('.zip') and 'Mac' in name:
        print(asset['browser_download_url'])
        break
else:
    # Fallback: source zip
    print(data.get('zipball_url', ''))
" 2>/dev/null || echo "")

            if [[ -z "$DOWNLOAD_URL" ]]; then
                echo -e "${RED}[✗]${NC} Не найден zip в релизе"
                USE_LOCAL=true
            else
                echo -e "${CYAN}[2/6]${NC} Скачиваю версию ${REMOTE_VERSION}..."
                TMP_ZIP="/tmp/${APP_NAME}_${REMOTE_VERSION}.zip"
                curl -L -o "$TMP_ZIP" "$DOWNLOAD_URL" --progress-bar

                echo -e "${CYAN}[3/6]${NC} Распаковываю в ${INSTALL_DIR}..."
                mkdir -p "$INSTALL_DIR"
                TMP_EXTRACT="/tmp/${APP_NAME}_extract"
                rm -rf "$TMP_EXTRACT"
                mkdir -p "$TMP_EXTRACT"
                unzip -qo "$TMP_ZIP" -d "$TMP_EXTRACT"

                # Находим папку внутри zip (может быть с префиксом)
                INNER=$(find "$TMP_EXTRACT" -maxdepth 1 -type d | tail -1)
                if [[ "$INNER" == "$TMP_EXTRACT" ]]; then
                    INNER="$TMP_EXTRACT"
                fi

                # Распаковываем НЕ трогая пользовательские файлы
                rsync -a \
                    --exclude='config.json' \
                    --exclude='settings.json' \
                    --exclude='models/' \
                    --exclude='downloads/' \
                    --exclude='voicer_debug.log' \
                    --exclude='.venv/' \
                    --exclude='__pycache__/' \
                    --exclude='build/' \
                    --exclude='dist/' \
                    --exclude='logs/' \
                    "${INNER}/" "${INSTALL_DIR}/"

                rm -rf "$TMP_ZIP" "$TMP_EXTRACT"
                echo -e "${GREEN}[✓]${NC} Файлы обновлены"
            fi
        fi
    fi
fi

# ============================================================
#  РЕЖИМ 2: Локальная установка (из текущей папки)
# ============================================================
if [[ "$USE_LOCAL" == "true" ]]; then
    echo -e "${CYAN}[2/6]${NC} Локальная установка из ${SCRIPT_DIR}"
    INSTALL_DIR="$SCRIPT_DIR"
    mkdir -p "$INSTALL_DIR"
fi

cd "$INSTALL_DIR"

# ============================================================
#  Homebrew
# ============================================================
if ! command -v brew &>/dev/null; then
    echo -e "${CYAN}[4/6]${NC} Устанавливаю Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    if [[ -f /opt/homebrew/bin/brew ]]; then
        eval "$(/opt/homebrew/bin/brew shellenv)"
    elif [[ -f /usr/local/bin/brew ]]; then
        eval "$(/usr/local/bin/brew shellenv)"
    fi
else
    echo -e "${GREEN}[✓]${NC} Homebrew уже установлен"
fi

# ============================================================
#  Python + python-tk + FFmpeg
# ============================================================
echo -e "${CYAN}[5/6]${NC} Проверяю зависимости..."

if ! command -v python3 &>/dev/null; then
    echo -e "  Устанавливаю Python..."
    brew install python
fi

# python-tk нужен для tkinter (filedialog и прочее)
if ! python3 -c "import tkinter" 2>/dev/null; then
    echo -e "  Устанавливаю python-tk..."
    brew install python-tk 2>/dev/null || echo -e "  ${YELLOW}⚠ python-tk уже установлен или недоступен${NC}"
fi

if ! command -v ffmpeg &>/dev/null; then
    echo -e "  Устанавливаю FFmpeg..."
    brew install ffmpeg
fi

echo -e "${GREEN}[✓]${NC} Зависимости системы готовы"

# ============================================================
#  Python venv + pip
# ============================================================
echo -e "${CYAN}[6/6]${NC} Настраиваю Python-окружение..."

if [ ! -d ".venv" ]; then
    python3 -m venv .venv
fi

source .venv/bin/activate
pip install --upgrade pip -q

# Устанавливаем зависимости
if [[ -f "requirements_mac.txt" ]]; then
    pip install -q -r requirements_mac.txt
elif [[ -f "requirements.txt" ]]; then
    pip install -q -r requirements.txt
else
    pip install -q eel gevent requests python-docx openai-whisper torch
fi

echo -e "${GREEN}[✓]${NC} Python-зависимости установлены"

# ============================================================
#  Записываем версию
# ============================================================
if [[ "$USE_LOCAL" == "false" && -n "$REMOTE_VERSION" ]]; then
    echo "$REMOTE_VERSION" > version.txt
fi

# ============================================================
#  Ярлык на Desktop
# ============================================================
cat > "$DESKTOP_SHORTCUT" << LAUNCHER_EOF
#!/bin/bash
cd "${INSTALL_DIR}"
source .venv/bin/activate
python3 main.py
LAUNCHER_EOF
chmod +x "$DESKTOP_SHORTCUT"

# ============================================================
#  Готово!
# ============================================================
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║${NC}  ${GREEN}${BOLD}Установка завершена!${NC}                     ${CYAN}║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Ярлык: ${BOLD}~/Desktop/${APP_NAME}.command${NC}"
echo -e "  Папка: ${BOLD}${INSTALL_DIR}${NC}"
echo ""
if [[ "$USE_LOCAL" == "false" && -n "$REMOTE_VERSION" ]]; then
    echo -e "  Версия: ${BOLD}${REMOTE_VERSION}${NC}"
fi
echo ""
echo -e "  ${CYAN}Для обновления дважды кликните UPDATE.command${NC}"
echo ""

# ============================================================
#  Запуск
# ============================================================
echo -e "${CYAN}Запускаю приложение...${NC}"
source .venv/bin/activate
python3 main.py
